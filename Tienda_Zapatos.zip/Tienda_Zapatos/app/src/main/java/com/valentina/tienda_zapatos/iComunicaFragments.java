package com.valentina.tienda_zapatos;

import com.valentina.tienda_zapatos.Entidades.Producto;

public interface iComunicaFragments {
    public void enviarProducto(Producto producto);

}
